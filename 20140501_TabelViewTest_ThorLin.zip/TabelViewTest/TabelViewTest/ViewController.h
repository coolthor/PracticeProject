//
//  ViewController.h
//  TabelViewTest
//
//  Created by Thor Lin on 2014/5/2.
//  Copyright (c) 2014年 Thor Lin. All rights reserved.
//

#import <UIKit/UIKit.h>
//成功的case
//原本UIViewController 手動改寫成UITableViewController
@interface ViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>

@end
